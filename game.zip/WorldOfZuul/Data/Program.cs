using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

class Exit
{
    public string Name { get; set; }
    public string TargetRoomId { get; set; }
}

class Room
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public List<Exit> Exits { get; set; }
}

class Location
{
    public string Id { get; set; }
    public string Name { get; set; }
    public List<Room> Rooms { get; set; }
}

class Root
{
    public List<Location> Locations { get; set; }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8; 

        
        string json = File.ReadAllText("World.json");
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        Root root = JsonSerializer.Deserialize<Root>(json, options);

        
        Console.WriteLine("═══════════════════════════════════════════════");
        Console.WriteLine("                 COURT HOUSE");
        Console.WriteLine("═══════════════════════════════════════════════");

        foreach (var location in root.Locations)
        {
            foreach (var room in location.Rooms)
            {
                Console.WriteLine($"\n[{room.Name}]");
                Console.WriteLine("═══════════════════════════════════════════════");

                foreach (var exit in room.Exits)
                {
                    Console.WriteLine($"   │");
                    Console.WriteLine($"   ▼");
                    Console.WriteLine($" -> {exit.TargetRoomId}");
                }
            }
        }
    }
}